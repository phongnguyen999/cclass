/**
 * BSTree class (Lab 9) configuration file.
 * Activate test 'N' by defining the corresponding LAB9_TESTN to have the value 1.
 * Deactive test 'N' by setting the value to 0.
 */

#define LAB9_TEST1	0		// Programming Exercise 2: getCount
#define LAB9_TEST2	0		// Programming Exercise 2: getHeight
#define LAB9_TEST3	0		// Programming Exercise 3: writeLessThan

