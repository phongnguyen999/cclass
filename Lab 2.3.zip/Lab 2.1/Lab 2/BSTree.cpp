#include <iostream>
#include "BSTree.h"
#include <cassert>
using namespace std;

/** Default Constructor
*/
template < typename DataType, class KeyType >
BSTree<DataType, KeyType>::BSTree()
{
	root = NULL;
}

/** Copy Constructor
*/
template < typename DataType, class KeyType >
BSTree<DataType, KeyType>::BSTree(const BSTree<DataType, KeyType>& other)
{
	*this = other;
}

template<typename DataType, class KeyType>BSTree<DataType, KeyType>::BSTreeNode::BSTreeNode(const DataType& nodeDataItem,BSTreeNode* leftPtr, BSTreeNode* rightPtr) 
	: dataItem(nodeDataItem),left(leftPtr), right(rightPtr)
{

}
/** The overloaded assignment operator
*/
template<typename DataType, class KeyType>
BSTree<DataType, KeyType>& BSTree<DataType, KeyType>::operator=(const BSTree<DataType, KeyType>& other)
{

	copyTree(root, other.root);
	return *this;
}

/** Method help clone subtree
*/
template < typename DataType, class KeyType >
void BSTree<DataType, KeyType>::copyTree(BSTreeNode* & thisRoot, BSTreeNode* other)
{
	if (other != NULL)
	{
		BSTreeNode *left = NULL;
		BSTreeNode *right = NULL;
		copyHelper(left, other->left);  //Copy left branch
		copyHelper(right, other - right); //Copy right branch
		thisRoot = new BSTreeNode(other->dataItem, left, right); //Reached leaf
	}
}

/**
*Destructure for the tree
*/
template < typename DataType, class KeyType >
BSTree<DataType, KeyType>::~BSTree()
{
	clear();
}

/**
* Method to make substree empty. Recursively 
*/
template < typename DataType, class KeyType >
void BSTree<DataType, KeyType>::clear()
{
	clearHelper(root);
}

template < typename DataType, class KeyType >
void BSTree<DataType, KeyType>::clearHelper(BSTreeNode * & p)
{
	if (p != nullptr)
	{
		clearHelper(p->left);
		clearHelper(p->right);
		delete p;
	}
	p = nullptr;
}
/** Returns true if Tree is empty
*Otherwise false.
*/
template < typename DataType, typename KeyType >
bool BSTree<DataType, KeyType>::isEmpty()
{
	return (root = NULL);

}

/** Output a subtree in sorted order
*/
template < typename DataType, typename KeyType >
void BSTree<DataType, KeyType>::writeKeys() const
{
	writeKeysHelper(root);
}

/** Recursive helper function to output the keys in the tree
*/
template < typename DataType, typename KeyType >
void BSTree<DataType, KeyType>::writeKeysHelper(BSTreeNode *p) const
{
	if (p != nullptr)
	{
		writeKeysHelper(p->left);
		cout << p->dataItem.getKey() << endl;
		writeKeysHelper(p->right);
	}
}


/** Remove data item
*/
template < typename DataType, typename KeyType >
bool BSTree<DataType, KeyType>::remove(const KeyType& deletekey)
{

	return deleteTree(root, deletekey);
	//contents
}

/** Helper function for deleting an item
*/
template < typename DataType, typename KeyType >
void BSTree<DataType, KeyType>::deleteTree(BSTreeNode*& p, const DataType& deleteItem)
{
	if (p = nullptr)
		return false;
	if (deleteItem < p->dataItem.getKey())
		deleteTree(p->left, deleteItem);
	else if (p->dataItem.getKey() < deleteItem)
		deleteTree(p->right, deleteItem);
	else if (p->left != 0 && p->right != 0)
	{
		;
	}
	return true;
	
	

	

}

/** Retrieve data item
*/
//template < typename DataType, typename KeyType >
//bool BSTree<DataType, KeyType>::retrieve( const KeyType& searchKey, DataType& searchDataItem) const
//
//{
//	//contents
//}


/** Insert data item
*/
template < typename DataType, typename KeyType >
void BSTree<DataType, KeyType>::insert(const DataType& newDataItem)
{
	insertTree(root, newDataItem);
}
/**
* Method to insert into a subtree
*/
template<typename DataType, class KeyType>
void BSTree<DataType, KeyType>::insertTree(BSTreeNode*& p, const DataType& newDataItem)
{
	
	if (p == NULL)
	{
		p = new BSTreeNode(newDataItem, NULL, NULL);
		assert(p != NULL);
	}
	else if (p->dataItem.getKey() > newDataItem.getKey())
		insertTree(p->left, newDataItem);

	else if (p->dataItem.getKey() < newDataItem.getKey())
		insertTree(p->right, newDataItem);
	else
		p->dataItem = newDataItem;
	
}

template < typename DataType, typename KeyType >
void BSTree<DataType, KeyType>::showStructure() const

/** Outputs the keys in a binary search tree. The tree is output
* rotated counterclockwise 90 degrees from its conventional
* orientation using a "reverse" inorder traversal. This operation is
* intended for testing and debugging purposes only.
*/

{
	if (root == 0)
		cout << "Empty tree" << endl;
	else
	{
		cout << endl;
		showHelper(root, 1);
		cout << endl;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template < typename DataType, typename KeyType >
void BSTree<DataType, KeyType>::showHelper(BSTreeNode *p,
	int level) const

	/** Recursive helper for showStructure. 
	* Outputs the subtree whose root node is pointed to by p. 
	* Parameter level is the level of this node within the tree.
	*/

{
	int j;   // Loop counter

	if (p != 0)
	{
		showHelper(p->right, level + 1);         // Output right subtree
		for (j = 0; j < level; j++)    // Tab over to level
			cout << "\t";
		cout << " " << p->dataItem.getKey();   // Output key
		if ((p->left != 0) &&           // Output "connector"
			(p->right != 0))
			cout << "<";
		else if (p->right != 0)
			cout << "/";
		else if (p->left != 0)
			cout << "\\";
		cout << endl;
		showHelper(p->left, level + 1);          // Output left subtree
	}
}

