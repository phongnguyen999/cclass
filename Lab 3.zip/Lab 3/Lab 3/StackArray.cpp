
#include <iostream>
#include "StackArray.h"

using namespace std;

template <typename DataType>
StackArray<DataType>::StackArray(int maxNumber)
{
	if (maxNumber <= 0)
	{
		cout << "Size of the array to hold the stack must "
			<< "be positive." << endl;
	}
	else
		maxSize = maxNumber;

	top = -1;
	dataItems = new DataType[maxSize];
}

template <typename DataType>
StackArray<DataType>& StackArray<DataType>::operator=(const StackArray& other)
{
	if (this != &other)
		copyHelper(other);
	return *this;
}

template <typename DataType>
StackArray<DataType>::StackArray(const StackArray& other)
{
	dataItems = NULL;
	copyHelper(other);
}


template <typename DataType>
StackArray<DataType>::~StackArray()
{
	delete[] dataItems;
}

template <typename DataType>
void StackArray<DataType>::push(const DataType& newDataItem) throw (logic_error)
{
	if (!isFull())
	{
		dataItems[top+1] = newDataItem;  //add newDataItem to the stack
		top++;  //increment top
	}
	else
		throw logic_error("Cannot add to a full stack");
}

template <typename DataType>
DataType StackArray<DataType>::pop() throw (logic_error)
{
	if (!isEmpty())
	{
		DataType temp = dataItems[top];
		dataItems[top] = 0;
		top--;
		return dataItems[top+1];
	}
	else
		throw logic_error("Cannot remove from an empty stack.");

}

template <typename DataType>
bool StackArray<DataType>::isEmpty() const
{
	return(top == -1);
}

template <typename DataType>
bool StackArray<DataType>::isFull() const
{
	return(top == maxSize-1);
}

template <typename DataType>
void StackArray<DataType>::clear()
{
	top = -1;
}
template <typename DataType>
void StackArray<DataType>::copyHelper(const StackArray& otherStack)
{
	delete[] dataItems;
	maxSize = otherStack.maxSize;
	top = otherStack.top;

	dataItems = new DataType[maxSize];

	for (int j = 0; j < top; j++)
		dataItem[j] = otherStack.dataItems[j];
}

template <typename DataType>
void StackArray<DataType>::showStructure() const

// Array implementation. Outputs the data items in a stack. If the
// stack is empty, outputs "Empty stack". This operation is intended
// for testing and debugging purposes only.

{
	if (isEmpty()) {
		cout << "Empty stack." << endl;
	}
	else {
		int j;
		cout << "Top = " << top << endl;
		for (j = 0; j < maxSize; j++)
			cout << j << "\t";
		cout << endl;
		for (j = 0; j <= top; j++)
		{
			if (j == top)
			{
				cout << '[' << dataItems[j] << ']' << "\t"; // Identify top
			}
			else
			{
				cout << dataItems[j] << "\t";
			}
		}
		cout << endl;
	}
	cout << endl;
}
