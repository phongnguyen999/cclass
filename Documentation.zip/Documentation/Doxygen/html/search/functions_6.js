var searchData=
[
  ['text',['Text',['../class_text.html#a1d8940dbb8b0c92b21ef31b4f049a65a',1,'Text::Text(const char *charSeq=&quot;&quot;)'],['../class_text.html#a5c3b7e0a778bd38ca25ca14209fd77df',1,'Text::Text(const Text &amp;other)']]],
  ['tolower',['toLower',['../class_text.html#a1ec9db5527b4c9e3192b95ed03b5b6d7',1,'Text']]],
  ['toupper',['toUpper',['../class_text.html#a3a9da838da19ed9e1d32767f45eee77a',1,'Text']]]
];
