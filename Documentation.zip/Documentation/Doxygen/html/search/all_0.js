var searchData=
[
  ['buffer',['buffer',['../class_text.html#ad50b3bc9f9306c1c234624f0b4095f6a',1,'Text']]],
  ['buffersize',['bufferSize',['../class_text.html#a0d16720e1aef31aacf0429ae8e0895bd',1,'Text']]]
];
