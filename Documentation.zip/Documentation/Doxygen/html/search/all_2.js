var searchData=
[
  ['getlength',['getLength',['../class_text.html#aa538b21160165d28fbaf706c51221ef3',1,'Text']]]
];
