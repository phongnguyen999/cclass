var searchData=
[
  ['showstructure',['showStructure',['../class_text.html#a7e84848b6d2cb843698097d9971bf0fe',1,'Text']]]
];
