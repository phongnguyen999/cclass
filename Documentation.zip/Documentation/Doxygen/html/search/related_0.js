var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../class_text.html#a80bc62c1929c393ff955cff5478b4ae8',1,'Text']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../class_text.html#a600bd9159aa00dc8bc726fb389be0f57',1,'Text']]]
];
