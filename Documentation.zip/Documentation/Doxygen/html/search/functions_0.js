var searchData=
[
  ['clear',['clear',['../class_text.html#a7dacbbf887593bff5a5e45cde06dca71',1,'Text']]],
  ['copytester',['copyTester',['../test1_8cpp.html#a56761cd98e3f75d438ed083394c80cc9',1,'test1.cpp']]]
];
