var searchData=
[
  ['_7etext',['~Text',['../class_text.html#a2d49e5c280e205125b149f7777ae30c7',1,'Text']]]
];
