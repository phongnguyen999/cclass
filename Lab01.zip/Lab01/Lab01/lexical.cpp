/*
	Project Name : Lab 1-Exercise 1
	Developer Name : Phong Nguyen
	Date : 01/19/2018
	Description : Lexical Analysis Program
*/

#include <fstream>
#include <iostream>
#include "Text.h"

int main()
{
	ifstream infile;
	 
	Text token;       // Token

	infile.open("progsamp.dat");    // Open the specified program file.
	
	if (!infile.is_open())

		cout << "Error opening file" << endl;

	else
	{
		int i = 0;    // Counts tokens
		while (infile >> token)
		{
			i++;
			cout << i << " : " << " [" << token << "]" << endl; 
		}
	}	

	infile.close();    // Close the file


	return 0;
}