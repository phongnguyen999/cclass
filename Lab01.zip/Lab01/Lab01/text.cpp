#include <iostream>
#include <iomanip>
#include <cassert>
#include <cstring>
#include "Text.h"

using namespace std;


using namespace std;

Text::Text(const char* charSeq) 
{
	bufferSize = strlen(charSeq) +1 ;
	try
	{
		buffer = new char[bufferSize];
	}
	catch (bad_alloc& e)
	{
		cout << "Allocate Memory Failed" << e.what() << endl;
	}
	
	strcpy(buffer, charSeq);
}

Text::Text(const Text& other)
{
	bufferSize = other.bufferSize;
	buffer = new char[bufferSize];
	strcpy(buffer, other.buffer);
}

void Text::operator = (const Text& other) {
	if (other.getLength() > bufferSize) {
		delete[] buffer;
		bufferSize = other.getLength() + 1;
		buffer = new char[bufferSize];

	}
	strcpy(buffer, other.buffer);
}

char Text::operator [] (int n) const {
	assert(0 <= n&&n < bufferSize);
	return buffer[n];
}

int Text::getLength()const {
	return strlen(buffer);
}



void Text::clear() {
	buffer[0] = '\0';
}

Text::~Text() {
	delete []buffer;
	bufferSize = 0;
}

void Text::showStructure()const {
	cout << buffer << endl;
}

//--------------------------------------------------------------------

istream & operator >> (istream &input, Text &inputText)

// Text input function. Extracts a string from istream input and
// returns it in inputText. Returns the state of the input stream.

{
	const int textBufferSize = 256;     // Large (but finite)
	char textBuffer[textBufferSize];   // text buffer

									   // Read a string into textBuffer, setw is used to prevent buffer
									   // overflow.

	input >> setw(textBufferSize) >> textBuffer;

	// Apply the Text(char*) constructor to convert textBuffer to
	// a string. Assign the resulting string to inputText using the
	// assignment operator.

	inputText = textBuffer;

	// Return the state of the input stream.

	return input;
}

//--------------------------------------------------------------------

ostream & operator << (ostream &output, const Text &outputText)

// Text output function. Inserts outputText in ostream output.
// Returns the state of the output stream.

{
	output << outputText.buffer;
	return output;
}