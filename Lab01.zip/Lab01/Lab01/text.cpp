#include <iostream>
#include <iomanip>
#include <cassert>
#include <cstring>
#include "Text.h"

using namespace std;


using namespace std;

Text::Text(const char* charSeq) 
// Creates a string containing the delimited sequence of characters
// charSeq. Allocates enough memory for this string.
{
	bufferSize = strlen(charSeq) +1 ;
	try
	{
		buffer = new char[bufferSize];
	}
	catch (bad_alloc& e)
	{
		cout << "Allocate Memory Failed" << e.what() << endl;
	}
	
	strcpy(buffer, charSeq);            // Copy the string
}

//--------------------------------------------------------------------

Text::Text(const Text& other)
// Copy constructor
{
	bufferSize = other.bufferSize;
	buffer = new char[bufferSize];
	strcpy(buffer, other.buffer);
}

//--------------------------------------------------------------------

void Text::operator = (const Text& other)
// Assigns other to a Text object.
{
	if (other.getLength() > bufferSize) {
		delete[] buffer;
		bufferSize = other.getLength() + 1;
		buffer = new char[bufferSize];

	}
	strcpy(buffer, other.buffer);
}

//--------------------------------------------------------------------

char Text::operator [] (int n) const

// Returns the nth character in a Text object -- where the characters are
// numbered beginning with zero.

{
	assert(0 <= n&&n < bufferSize);
	return buffer[n];
}

//--------------------------------------------------------------------

int Text::getLength()const
// Returns the number of characters in the Text object buffer (excluding the
// null character).

{
	return strlen(buffer);
}

//--------------------------------------------------------------------

void Text::clear()

// Clears a Text object -- i.e., makes it empty. The buffer size
// remains unchanged.

{
	buffer[0] = '\0';
}

//--------------------------------------------------------------------

Text::~Text()
// Frees the memory used by the Text object buffer.
{
	delete []buffer;
	bufferSize = 0;
}

void Text::showStructure()const

// Outputs the characters in a string. This operation is intended for
// testing/debugging purposes only.


{
	int j;   // Loop counter

	for (j = 0; j < bufferSize; j++)
		cout << j << "  ";
	cout << endl;
	for (j = 0; buffer[j] != '\0'; j++) 
		cout << buffer[j] << "  ";
	cout << "\\0" << endl;
	//cout << buffer << endl;
}

//--------------------------------------------------------------------

istream & operator >> (istream &input, Text &inputText)

// Text input function. Extracts a string from istream input and
// returns it in inputText. Returns the state of the input stream.

{
	const int textBufferSize = 256;     // Large (but finite)
	char textBuffer[textBufferSize];   // text buffer

									   // Read a string into textBuffer, setw is used to prevent buffer
									   // overflow.

	input >> setw(textBufferSize) >> textBuffer;

	// Apply the Text(char*) constructor to convert textBuffer to
	// a string. Assign the resulting string to inputText using the
	// assignment operator.

	inputText = textBuffer;

	// Return the state of the input stream.

	return input;
}

//--------------------------------------------------------------------

ostream & operator << (ostream &output, const Text &outputText)

// Text output function. Inserts outputText in ostream output.
// Returns the state of the output stream.

{
	output << outputText.buffer;
	return output;
}