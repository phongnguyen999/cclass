/**--------------------------------------------------------------------
*
*  Laboratory 11, In-lab Exercise 1                     database.cpp
*
*  (Shell) Indexed accounts database program
*
*--------------------------------------------------------------------
*/
/** Builds a binary search tree index for the account records in the
* text file accounts.dat.
*/
#include <iostream>
#include <fstream>
#include "BSTree.cpp"

using namespace std;

/**--------------------------------------------------------------------
*
* Declarations specifying the accounts database
*/

const int nameLength = 11;   // Maximum number of characters in
							 //   a name
const long bytesPerRecord = 38;   // Number of bytes used to store
								  //   each record in the accounts
								  //   database file

struct AccountRecord
{
	int acctID;                   // Account identifier
	char firstName[nameLength],   // Name of account holder
		lastName[nameLength];
	double balance;               // Account balance
};

/**--------------------------------------------------------------------
*
* Declaration specifying the database index
*/

struct IndexEntry
{
	int acctID;              // (Key) Account identifier
	long recNum;             // Record number

	int getKey() const
	{
		return acctID;
	}   // Return key field
};

//--------------------------------------------------------------------

//void main()
//{
//	ifstream acctFile("accounts.dat");   // Accounts database file
//	AccountRecord acctRec;                // Account record
//	BSTree<IndexEntry, int> index;         // Database index
//	IndexEntry entry;                     // Index entry
//	int searchID;                         // User input account ID
//	long recNum;                          // Record number
//	                      
//
//	acctFile >> entry.acctID;			// Iterate through the database records. For each record, read the
//	recNum = 0;
//	while (acctFile.good())
//	{
//		entry.recNum = recNum;
//
//		index.insert(entry);
//
//		recNum++;
//		acctFile.seekg(recNum *bytesPerRecord, acctFile.beg);// seek recNum *bytesPerRecord from the begining of the file
//		acctFile >> entry.acctID;
//	}										  // account ID and add the (account ID, record number) pair to the
//	
//											  // index.
//	cout << endl << "Account IDs:" << endl;									 
//	index.writeKeys();                // Output the account IDs in ascending order.
//	cout << endl;
//	acctFile.clear();			 // Clear the status flags for the database file.
//	acctFile.seekg(0);
//														  
//	cout << "Enter account ID: ";													  // Get the record number to retrieve.
//	do 
//	{
//		cin >> searchID;
//		if (index.retrieve(searchID,entry))
//		{
//			acctFile.seekg((entry.recNum *bytesPerRecord), acctFile.beg); //move to the corresponding record in the database
//			acctFile >> acctRec.acctID >> acctRec.firstName >> acctRec.lastName >> acctRec.balance;//read in the record
//			cout << "Record #\t" << "Account ID\t" << "First Name\t" << "Last name\t" << "Balance" << endl;
//			cout << entry.recNum << "\t\t" << acctRec.acctID << "\t \t" << acctRec.firstName << " \t\t" << acctRec.lastName << "\t\t " << acctRec.balance << endl;
//		
//		}
//		else
//		{
//			cout << "No record # found" << endl;
//		}
//		cout << "Enter accound ID(Q to quit): ";
//	}
//	while (cin && (searchID != 'Q') && (searchID != 'q'));
//	    
//	    if ( !cin ) {
//		cerr << "Error in console input. Exiting." << endl;
//	    }
//	acctFile.close();
//	
//	
//
//}
