/**@file postfix.cpp
* Project Name : postfix.cpp || Lab 03
* Developer : Phong Nguyen
* Date : 03/06/2018
* Description : postfix calculator
*/

#include <iostream>
#include <iomanip>
#include "StackLinked.cpp"
using namespace std;

double evaluateOpr(char* ch)
{
	char currentChar = char(4);
	StackLinked<double> Stack; //create new stack from StackLinked type Double
	double op1, op2, result;
	op1 = 0.0;
	op2 = 0.0;
	for (int i = 0; i < 10; i++) //control loop if char over 10 character
	{
		currentChar = ch[i]; // read the character one by one 
		switch (currentChar)
		{
		case '0':         
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			Stack.push(double(currentChar-'0')); // single digit case, push to the stack
			result = Stack.pop();									 // remove whitespace character in calculation
			break;
		case '+':                  //case +            
			op2 = Stack.pop(); //pop number off stack and call it op2
			op1 = Stack.pop();
			result = op1 + op2;
			Stack.push(result);  //combine
			break;
		case '-'://case -
			op2 = Stack.pop();
			op1 = Stack.pop();

			result = op1 - op2;
			Stack.push(result);
			break;
		case '*':           //case *
			op2 = Stack.pop();
			op1 = Stack.pop();

			result = op1 * op2;
			Stack.push(result);
			break;
		case '/':           //case /
			op2 = Stack.pop();
			op1 = Stack.pop();
			if (op2 != 0)
				result = op1 / op2;
			else
				cout << "Division by Zero"<<endl;
			Stack.push(result);
			break;
			
		default:
			break;
		}
	}
	return result; // return result to main
}


//int main()
//{
//	double result;
//	char* ch = new char[10]; //new char to hold user input
//	
//	cout << "Enter postfix expresion: " << endl; // ask the user for expression
//	cin.getline(ch, 9); // one single line of input
//
//	result = evaluateOpr(ch); // evaluate the expression
//	cout << "=" << result << endl;
//
//	delete ch;      //delalocates memory after done
//	ch = NULL;
//
//	system("pause");
//	return 0;
//}