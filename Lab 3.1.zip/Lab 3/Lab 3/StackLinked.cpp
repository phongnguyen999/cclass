#include <iostream>
#include "StackLinked.h"

template <typename DataType>
StackLinked<DataType>::StackLinked(int maxNumber)
{
	top = NULL;
}

template <typename DataType>
StackLinked<DataType>::StackLinked(const StackLinked& other)
{
	top = NULL;
	copyHelper(other);
}

template <typename DataType>
StackLinked<DataType>::StackNode::StackNode(const DataType& nodeData,
	StackNode* nextPtr) {
	// initialize data members with given data
	dataItem = nodeData;
	next = nextPtr;

	// no return - constructor
}

template <typename DataType>
StackLinked<DataType>& StackLinked<DataType>::operator=(const StackLinked& other)
{
	if (this != &other)
		copyHelper(other);
	return *this;
}
template <typename DataType>
StackLinked<DataType>::~StackLinked()
{
	clear();
}

template <typename DataType>
bool StackLinked<DataType>::isEmpty() const
{
	return (top == NULL);
}

template <typename DataType>
bool StackLinked<DataType>::isFull() const
{
	return false;
}
template <typename DataType>
void StackLinked<DataType>::push(const DataType& newDataItem) throw (logic_error)
{
	StackNode * newNode;

	newNode = new StackNode(newDataItem, 0);
	newNode->dataItem = newDataItem;
	newNode->next = top;
	top = newNode;
}

template <typename DataType>
void StackLinked<DataType>::clear()
{
	StackNode *temp; //pointer to delete node
	while (top!= NULL)
	{
		temp = top;
		top = top->next;
		delete temp;
	}
}

template <typename DataType>
DataType StackLinked<DataType>::pop() throw (logic_error)
{
	StackNode *temp;
	if (top != NULL)
	{
		DataType mTop = top->dataItem;
		temp = top;
		top = top->next;
		delete temp;
		return mTop;
	}
	else
		throw logic_error("pop() while stack empty");
}
template <typename DataType>
void StackLinked<DataType>::copyHelper(const StackLinked& otherStack)
{
	StackNode *newNode, *current, *last;
	if (otherStack.top == NULL)
		top = NULL;
	else
	{
		current = otherStack.top; //set the current to point
		//to the top element of the stack
		top = new StackNode;
		top->dataItem = current->dataItem; //copy the dataItem
		top->next = NULL; //set the link field of the 
						  //node to NULL
		last = top;
		current = current->next;

		while (current != NULL)
		{
			newNode = new StackNode;

			newNode->dataItem = current->dataItem;
			newNode->next = NULL;
			last->next = newNode;
			current = current->next;
		}
	}
}

template <typename DataType>
void StackLinked<DataType>::showStructure() const

// Linked list implementation. Outputs the data elements in a stack.
// If the stack is empty, outputs "Empty stack". This operation is
// intended for testing and debugging purposes only.

{
	if (isEmpty())
	{
		cout << "Empty stack" << endl;
	}
	else
	{
		cout << "Top\t";
		for (StackNode* temp = top; temp != 0; temp = temp->next) {
			if (temp == top) {
				cout << "[" << temp->dataItem << "]\t";
			}
			else {
				cout << temp->dataItem << "\t";
			}
		}
		cout << "Bottom" << endl;
	}

}