#include <iostream>
#include "BSTree.h"
#include <cassert>
using namespace std;

/** Default Constructor
*/
template < typename DataType, class KeyType >
BSTree<DataType, KeyType>::BSTree()
{
	root = NULL;
}

/** Copy Constructor
*/
template < typename DataType, class KeyType >
BSTree<DataType, KeyType>::BSTree(const BSTree<DataType, KeyType>& other)
{
	*this = other;
}

template<typename DataType, class KeyType>BSTree<DataType, KeyType>::BSTreeNode::BSTreeNode(const DataType& nodeDataItem,BSTreeNode* leftPtr, BSTreeNode* rightPtr) 
	: dataItem(nodeDataItem),left(leftPtr), right(rightPtr)
{

}
/** The overloaded assignment operator
*/
template<typename DataType, class KeyType>
BSTree<DataType, KeyType>& BSTree<DataType, KeyType>::operator=(const BSTree<DataType, KeyType>& other)
{
	if (*this == &other)
		return *this;
	clear();
	copyTree(root, other.root);
	return *this;
}

/** Method help clone subtree
*/
template < typename DataType, class KeyType >
void BSTree<DataType, KeyType>::copyTree(BSTreeNode* & thisRoot, BSTreeNode* other)
{
	if (other != NULL)
	{
		BSTreeNode *left = NULL;
		BSTreeNode *right = NULL;
		copyHelper(left, other->left);  //Copy left branch
		copyHelper(right, other - right); //Copy right branch
		thisRoot = new BSTreeNode(other->dataItem, left, right); //Reached leaf
	}
}

/**
*Destructure for the tree
*/
template < typename DataType, class KeyType >
BSTree<DataType, KeyType>::~BSTree()
{
	clear();
}

/**
* Method to make substree empty. Recursively 
*/
template < typename DataType, class KeyType >
void BSTree<DataType, KeyType>::clear()
{
	clearHelper(root);
}

template < typename DataType, class KeyType >
void BSTree<DataType, KeyType>::clearHelper(BSTreeNode * & p)
{
	if (p != nullptr)
	{
		clearHelper(p->left);
		clearHelper(p->right);
		delete p;
	}
	p = nullptr;
}
/** Returns true if Tree is empty
*Otherwise false.
*/
template < typename DataType, typename KeyType >
bool BSTree<DataType, KeyType>::isEmpty() const
{
	return root == NULL;
	
}

/** Output a subtree in sorted order
*/
template < typename DataType, typename KeyType >
void BSTree<DataType, KeyType>::writeKeys() const
{
	writeKeysHelper(root);
}

/** Recursive helper function to output the keys in the tree
*/
template < typename DataType, typename KeyType >
void BSTree<DataType, KeyType>::writeKeysHelper(BSTreeNode *p) const
{
	if (p != nullptr)
	{
		writeKeysHelper(p->left);
		cout << p->dataItem.getKey() << endl;
		writeKeysHelper(p->right);
	}
}


/** Remove data item
* Removes the element with key deleteKey from a tree. If the
* element is found, then deletes it from the tree and returns True.
* Otherwise, returns False.
*/
template < typename DataType, typename KeyType >
bool BSTree<DataType, KeyType>::remove(const KeyType& deleteKey)
{

	return removeTree(root, deleteKey);
}

/** Remove data item
* Removes the element with key deleteKey from a tree. If the
* element is found, then deletes it from the tree and returns True.
* Otherwise, returns False.
*/
template < typename DataType, typename KeyType >
bool BSTree<DataType, KeyType>::removeTree(BSTreeNode*& p, const KeyType& deleteKey)
{

	bool results;                 // Result returned

	if (p == NULL)
		results = false;                               // Item not found; do nothing
	else if (deleteKey < p->dataItem.getKey())
		results = removeTree(p->left, deleteKey);    // Search left
	else if (deleteKey > p->dataItem.getKey())
		results = removeTree(p->right, deleteKey);   // Search right
	else
	{                                            // Found
		BSTreeNode *oldNode = p;
		if (p->left == NULL)
			p = p->right;                    // No left child
		else if (p->right == NULL)
			p = p->left;                     // No right child
		else
			removeTreeTwoChild(p->left, oldNode);    // have two children
		delete oldNode;
		results = true;
	}

	return results;
	
}

template < typename DataType, typename KeyType >
void BSTree<DataType, KeyType>::removeTreeTwoChild(BSTreeNode*& r, BSTreeNode*& oldNode)
{
	if (r->right != NULL)
		removeTreeTwoChild(r->right, oldNode);   // Continue down to the right
	else
	{
		oldNode->dataItem = r->dataItem;
		oldNode = r;
		r = r->left;
	}
}

/** Retrieve data item
*/
template < typename DataType, typename KeyType >
bool BSTree<DataType, KeyType>::retrieve( const KeyType& searchKey, DataType& searchDataItem) const

{
	return retrieveTree(root, searchKey, searchDataItem);
}

/** Retrieve data item with recursive 
* Searches the subtree pointed to by p
* results is boolean datatype
* return true if found otherwise return false if not found
*/
template < typename DataType, typename KeyType >
bool BSTree<DataType, KeyType>::retrieveTree(BSTreeNode* p, const KeyType searchKey, DataType& searchDataItem) const
{
	bool results;
	if (p == NULL)
		results = false;
	else if (searchKey < p->dataItem.getKey())
		results = retrieveTree(p->left, searchKey, searchDataItem);
	else if (searchKey > p->dataItem.getKey())
		results = retrieveTree(p->right, searchKey, searchDataItem);
	else
	{
		searchDataItem = p->dataItem;
		results = true;
	}

	return results;
}

/** Insert data item
*/
template < typename DataType, typename KeyType >
void BSTree<DataType, KeyType>::insert(const DataType& newDataItem)
{
	insertTree(root, newDataItem);
}

/**
*Recursive partner of the insert() function. Inserts newDataItem in
*the subtree pointed to by p.
*/
template<typename DataType, class KeyType>
void BSTree<DataType, KeyType>::insertTree(BSTreeNode*& p, const DataType& newDataItem)
{
	
	if (p == NULL)
	{
		p = new BSTreeNode(newDataItem, NULL, NULL);
		assert(p != NULL);
	}
	else if (p->dataItem.getKey() > newDataItem.getKey())
		insertTree(p->left, newDataItem);//search left

	else if (p->dataItem.getKey() < newDataItem.getKey())
		insertTree(p->right, newDataItem);//search right
	else
		p->dataItem = newDataItem;
	
}
/**
*Function to return the height of the tree
*Call recursive helper function
*/

template<typename DataType, class KeyType>
int BSTree< DataType, KeyType>::getHeight() const
{
	return getHeightHelper(root);
}
/**
* getHeight helper funtion
* compute the number of nodes along the longest path
* from the root node to the farthest leaf node
*/
template<typename DataType, class KeyType>
int BSTree< DataType, KeyType>::getHeightHelper(BSTreeNode * current)const
{
	if (current != NULL)
	{
		int leftHeight = getHeightHelper(current->left);
		int rightHeight = getHeightHelper(current->right);

		if (leftHeight > rightHeight) //return the longest path's height
			return(leftHeight + 1);
		else return (rightHeight + 1);
	}
	return 0; //Base case: empty tree has no nodes so return zero
}

/**
Count the number of data items in the binary search tree
*/
template<typename DataType, class KeyType>
int BSTree< DataType, KeyType>::getCount() const
{
	return countTree(root);
}

/**
Recursive helper function for counting nodes
*Given the root and will return number of nodes
*/
template<typename DataType, class KeyType>
int BSTree< DataType, KeyType>::countTree(BSTreeNode * current) const
{
	int count = 1; // count nodes in left, right subtree, add one for root
	
	if (current != NULL)
	{
		count += countTree(current->left);
		count += countTree(current->right);
		return count;
	}
	return 0;//Base case: empty tree has no nodes so return zero
}
template < typename DataType, typename KeyType >
void BSTree<DataType, KeyType>::showStructure() const

/** Outputs the keys in a binary search tree. The tree is output
* rotated counterclockwise 90 degrees from its conventional
* orientation using a "reverse" inorder traversal. This operation is
* intended for testing and debugging purposes only.
*/

{
	if (root == 0)
		cout << "Empty tree" << endl;
	else
	{
		cout << endl;
		showHelper(root, 1);
		cout << endl;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template < typename DataType, typename KeyType >
void BSTree<DataType, KeyType>::showHelper(BSTreeNode *p,
	int level) const

	/** Recursive helper for showStructure. 
	* Outputs the subtree whose root node is pointed to by p. 
	* Parameter level is the level of this node within the tree.
	*/

{
	int j;   // Loop counter

	if (p != 0)
	{
		showHelper(p->right, level + 1);         // Output right subtree
		for (j = 0; j < level; j++)    // Tab over to level
			cout << "\t";
		cout << " " << p->dataItem.getKey();   // Output key
		if ((p->left != 0) &&           // Output "connector"
			(p->right != 0))
			cout << "<";
		else if (p->right != 0)
			cout << "/";
		else if (p->left != 0)
			cout << "\\";
		cout << endl;
		showHelper(p->left, level + 1);          // Output left subtree
	}
}

